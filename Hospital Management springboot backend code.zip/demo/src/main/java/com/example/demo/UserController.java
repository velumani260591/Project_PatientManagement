package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/users")
public class UserController {

    @PostMapping("/add")
    public ResponseEntity<Map<String, String>> addUser(@RequestBody UserRequest userRequest) 
    {
    	Map<String, String> response = new HashMap<>();
    	try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) 
    	{
            MongoDatabase database = mongoClient.getDatabase("mydatabase");
            MongoCollection<Document> collection = database.getCollection("users");

            Document user = new Document("name", userRequest.getName())
                    .append("age", userRequest.getAge())
                    .append("email", userRequest.getEmail());

            collection.insertOne(user);
      
            response.put("message", "User saved successfully");
            return ResponseEntity.ok(response);
        }
    	catch (Exception e) 
    	{
            e.printStackTrace();
            return ResponseEntity.ok(response);
        }
    }

	@GetMapping("/user")
	public ResponseEntity<List<UserRequest>> getUser() {
		List<UserRequest> users = new ArrayList<>();
		Map<String, String> response = new HashMap<>();
		try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
			MongoDatabase database = mongoClient.getDatabase("mydatabase");
			MongoCollection<Document> collection = database.getCollection("users");

			// Find all documents
			FindIterable<Document> docs = collection.find();

			for (Document doc : docs) {
				UserRequest userRequests =new UserRequest();
				userRequests.setName(doc.get("name").toString());
				userRequests.setEmail(doc.get("email").toString());
				users.add(userRequests);
				System.out.println(doc.toJson());
			}
			response.put("message", "User saved successfully");
			return ResponseEntity.ok(users);
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.ok(users);
        }
    }
}
	